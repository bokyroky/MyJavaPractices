package com.paypal.api.payments;

public class TokenHolder {
	
	public static String accessToken = "";

}
